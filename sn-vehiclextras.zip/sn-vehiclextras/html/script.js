window.addEventListener('message', function(event) {
    if (event.data.type === "openUI") {
        document.getElementById('container').style.display = 'flex';
        setupMenu(event.data);
    }
});

const modLabels = {
    bumper_f: "Front Bumper",
    bumper_r: "Rear Bumper",
    skirt: "Side Skirts",
    exhaust: "Exhaust",
    cage: "Roll Cage / Chassis",
    grille: "Grille",
    hood: "Hood",
    fender_l: "Left Fender",
    fender_r: "Right Fender",
    roof: "Roof",
    plate_f: "Front Plate",
    plate_h: "Plate Frame",
    interior: "Interior",
    dashboard: "Dashboard",
    dial: "Gauges",
    door_spk: "Door Speakers",
    seats: "Seats",
    steering: "Steering Wheel",
    shifter: "Gear Shifter",
    plaques: "Plaques",
    trunk_spk: "Rear Speakers",
    hydraulics: "Hydraulics",
    engine_bay: "Engine Bay",
    air_filter: "Air Filter",
    struts: "Suspension",
    antenna: "Antenna",
    arch: "Arch Covers",
    support: "Supports",
    tank: "Fuel Tank",
    windows: "Windows"
};

function setupMenu(data) {
    const slider = document.getElementById('livery-slider');
    const countDisplay = document.getElementById('livery-count');
    
    let maxLiveries = data.liveries;
    if (data.liveryModCount && data.liveryModCount > maxLiveries) {
        maxLiveries = data.liveryModCount;
    }
    
    slider.max = maxLiveries > 0 ? maxLiveries - 1 : 0;
    slider.value = data.currentLivery;
    slider.disabled = maxLiveries <= 0;
    countDisplay.innerText = `#${data.currentLivery}`;

    const chassisList = document.getElementById('chassis-list');
    chassisList.innerHTML = '';
    
    for (const [key, modData] of Object.entries(data.vehicleMods)) {
        if (modData.count > 0) {
            chassisList.innerHTML += `
                <div class="option-card slider-card" style="margin-bottom: 5px;">
                    <i class="fas fa-tools"></i>
                    <div class="text-info" style="width: 100%;">
                        <div style="display: flex; justify-content: space-between;">
                            <h2 style="font-size: 13px;">${modLabels[key]}</h2>
                            <span id="count-${key}" class="badge">#${modData.current}</span>
                        </div>
                        <input type="range" min="-1" max="${modData.count - 1}"
                               value="${modData.current}"
                               class="modern-slider"
                               oninput="updateChassisMod('${key}', this.value)">
                    </div>
                </div>
            `;
        }
    }

    const extrasList = document.getElementById('extras-list');
    extrasList.innerHTML = '';
    data.extras.forEach(extra => {
        extrasList.innerHTML += createCard(
            'extra',
            extra.id,
            `Extra #${extra.id}`,
            `State: ${extra.state ? 'ON' : 'OFF'}`,
            extra.state
        );
    });
}

function updateChassisMod(type, value) {
    document.getElementById(`count-${type}`).innerText = `#${value}`;
    applyMod(type, value, null);
}

function updateLivery(value) {
    document.getElementById('livery-count').innerText = `#${value}`;
    applyMod('livery', value, null);
}

function createCard(type, id, title, desc, state = null) {
    return `
        <div class="option-card" onclick="applyMod('${type}', ${id}, ${!state})">
            <i class="fas fa-palette"></i>
            <div class="text-info">
                <h2>${title}</h2>
                <p>${desc}</p>
            </div>
        </div>
    `;
}

function applyMod(type, id, state) {
    fetch(`https://${GetParentResourceName()}/applyMod`, {
        method: 'POST',
        body: JSON.stringify({ type, id, state })
    });
}

function closeUI() {
    document.getElementById('container').style.display = 'none';
    fetch(`https://${GetParentResourceName()}/close`, { method: 'POST' });
}

document.onkeyup = function(data) {
    if (data.key === "Escape") closeUI();
};
