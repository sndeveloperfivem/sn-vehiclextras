RegisterCommand('extra', function()
    local ped = PlayerPedId()
    local vehicle = GetVehiclePedIsIn(ped, false)

    if vehicle ~= 0 then
        local class = GetVehicleClass(vehicle)

        if class == 15 or class == 18 then
            SetVehicleModKit(vehicle, 0)
            
            local extras = {}
            for i = 1, 15 do
                if DoesExtraExist(vehicle, i) then
                    table.insert(extras, {id = i, state = false})
                end
            end

            local mods = {
    bumper_f   = {count = GetNumVehicleMods(vehicle, 1),  current = GetVehicleMod(vehicle, 1)},
    bumper_r   = {count = GetNumVehicleMods(vehicle, 2),  current = GetVehicleMod(vehicle, 2)},
    skirt      = {count = GetNumVehicleMods(vehicle, 3),  current = GetVehicleMod(vehicle, 3)},
    exhaust    = {count = GetNumVehicleMods(vehicle, 4),  current = GetVehicleMod(vehicle, 4)},
    cage       = {count = GetNumVehicleMods(vehicle, 5),  current = GetVehicleMod(vehicle, 5)},
    grille     = {count = GetNumVehicleMods(vehicle, 6),  current = GetVehicleMod(vehicle, 6)},
    hood       = {count = GetNumVehicleMods(vehicle, 7),  current = GetVehicleMod(vehicle, 7)},
    fender_l   = {count = GetNumVehicleMods(vehicle, 8),  current = GetVehicleMod(vehicle, 8)},
    fender_r   = {count = GetNumVehicleMods(vehicle, 9),  current = GetVehicleMod(vehicle, 9)},
    roof       = {count = GetNumVehicleMods(vehicle, 10), current = GetVehicleMod(vehicle, 10)},
    plate_f    = {count = GetNumVehicleMods(vehicle, 25), current = GetVehicleMod(vehicle, 25)},
    plate_h    = {count = GetNumVehicleMods(vehicle, 26), current = GetVehicleMod(vehicle, 26)},
    interior   = {count = GetNumVehicleMods(vehicle, 27), current = GetVehicleMod(vehicle, 27)},
    dashboard  = {count = GetNumVehicleMods(vehicle, 29), current = GetVehicleMod(vehicle, 29)},
    dial       = {count = GetNumVehicleMods(vehicle, 30), current = GetVehicleMod(vehicle, 30)},
    door_spk   = {count = GetNumVehicleMods(vehicle, 31), current = GetVehicleMod(vehicle, 31)},
    seats      = {count = GetNumVehicleMods(vehicle, 32), current = GetVehicleMod(vehicle, 32)},
    steering   = {count = GetNumVehicleMods(vehicle, 33), current = GetVehicleMod(vehicle, 33)},
    shifter    = {count = GetNumVehicleMods(vehicle, 34), current = GetVehicleMod(vehicle, 34)},
    plaques    = {count = GetNumVehicleMods(vehicle, 35), current = GetVehicleMod(vehicle, 35)},
    trunk_spk  = {count = GetNumVehicleMods(vehicle, 36), current = GetVehicleMod(vehicle, 36)},
    hydraulics = {count = GetNumVehicleMods(vehicle, 38), current = GetVehicleMod(vehicle, 38)},
    engine_bay = {count = GetNumVehicleMods(vehicle, 39), current = GetVehicleMod(vehicle, 39)},
    air_filter = {count = GetNumVehicleMods(vehicle, 40), current = GetVehicleMod(vehicle, 40)},
    struts     = {count = GetNumVehicleMods(vehicle, 41), current = GetVehicleMod(vehicle, 41)},
    antenna    = {count = GetNumVehicleMods(vehicle, 42), current = GetVehicleMod(vehicle, 42)},
    arch       = {count = GetNumVehicleMods(vehicle, 43), current = GetVehicleMod(vehicle, 43)},
    support    = {count = GetNumVehicleMods(vehicle, 44), current = GetVehicleMod(vehicle, 44)},
    tank       = {count = GetNumVehicleMods(vehicle, 45), current = GetVehicleMod(vehicle, 45)},
    windows    = {count = GetNumVehicleMods(vehicle, 46), current = GetVehicleMod(vehicle, 46)}
}



        local currentLivery = GetVehicleLivery(vehicle)
        if GetNumVehicleMods(vehicle, 48) > 0 then
            currentLivery = GetVehicleMod(vehicle, 48)
        end

        local extras = {}
        for i = 1, 15 do
            if DoesExtraExist(vehicle, i) then
                table.insert(extras, {id = i, state = IsVehicleExtraTurnedOn(vehicle, i)})
            end
        end

        SetNuiFocus(true, true)
            SendNUIMessage({
                type = "openUI",
                currentLivery = currentLivery,
                liveries = GetVehicleLiveryCount(vehicle),
                liveryModCount = GetNumVehicleMods(vehicle, 48),
                extras = extras,
                vehicleMods = mods 
            })
        else

            print("Vehiculo no permitido")
        end
    end
end, false)

RegisterNUICallback('applyMod', function(data, cb)
    local vehicle = GetVehiclePedIsIn(PlayerPedId(), false)

    if vehicle ~= 0 then
        SetVehicleModKit(vehicle, 0)

        local id = tonumber(data.id)

        if data.type == "livery" then
            SetVehicleLivery(vehicle, id)
            if GetNumVehicleMods(vehicle, 48) > 0 then
                SetVehicleMod(vehicle, 48, id, false)
            end

        elseif data.type == "extra" then
            SetVehicleExtra(vehicle, id, data.state and 0 or 1)


        elseif data.type == "bumper_f"   then SetVehicleMod(vehicle, 1,  id, false)
        elseif data.type == "bumper_r"   then SetVehicleMod(vehicle, 2,  id, false)
        elseif data.type == "skirt"      then SetVehicleMod(vehicle, 3,  id, false)
        elseif data.type == "exhaust"    then SetVehicleMod(vehicle, 4,  id, false)
        elseif data.type == "cage"       then SetVehicleMod(vehicle, 5,  id, false)
        elseif data.type == "grille"     then SetVehicleMod(vehicle, 6,  id, false)
        elseif data.type == "hood"       then SetVehicleMod(vehicle, 7,  id, false)
        elseif data.type == "fender_l"   then SetVehicleMod(vehicle, 8,  id, false)
        elseif data.type == "fender_r"   then SetVehicleMod(vehicle, 9,  id, false)
        elseif data.type == "roof"       then SetVehicleMod(vehicle, 10, id, false)


        elseif data.type == "interior"   then SetVehicleMod(vehicle, 27, id, false)
        elseif data.type == "dashboard"  then SetVehicleMod(vehicle, 29, id, false)
        elseif data.type == "dial"       then SetVehicleMod(vehicle, 30, id, false)
        elseif data.type == "door_spk"   then SetVehicleMod(vehicle, 31, id, false)
        elseif data.type == "seats"      then SetVehicleMod(vehicle, 32, id, false)
        elseif data.type == "steering"   then SetVehicleMod(vehicle, 33, id, false)
        elseif data.type == "shifter"    then SetVehicleMod(vehicle, 34, id, false)
        elseif data.type == "plaques"    then SetVehicleMod(vehicle, 35, id, false)
        elseif data.type == "trunk_spk"  then SetVehicleMod(vehicle, 36, id, false)


        elseif data.type == "hydraulics" then SetVehicleMod(vehicle, 38, id, false)
        elseif data.type == "engine_bay" then SetVehicleMod(vehicle, 39, id, false)
        elseif data.type == "air_filter" then SetVehicleMod(vehicle, 40, id, false)
        elseif data.type == "struts"     then SetVehicleMod(vehicle, 41, id, false)
        elseif data.type == "antenna"    then SetVehicleMod(vehicle, 42, id, false)
        elseif data.type == "arch"       then SetVehicleMod(vehicle, 43, id, false)
        elseif data.type == "support"    then SetVehicleMod(vehicle, 44, id, false)
        elseif data.type == "tank"       then SetVehicleMod(vehicle, 45, id, false)
        elseif data.type == "windows"    then SetVehicleMod(vehicle, 46, id, false)
        elseif data.type == "plate"      then SetVehicleMod(vehicle, 25, id, false)
        end
    end

    cb('ok')
end)


RegisterNUICallback('close', function(data, cb)
    SetNuiFocus(false, false)
    cb('ok')
end)